from setuptools import setup

setup(
    name='lecture072',
    version='1.0.0',
    packages=['', 'lesson_package', 'lesson_package.talk', 'lesson_package.tools'],
    url='dummy_url',
    license='free',
    author='takuya mogawa',
    author_email='takuyamogawa@google.com',
    description=''
)
