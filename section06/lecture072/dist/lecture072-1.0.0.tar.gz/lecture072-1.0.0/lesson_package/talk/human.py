# from section06.lecture070.lesson_package.tools import utils
import lesson_package.tools.utils

def sing():
    return 'sing'

def cry():
    return 'cry'