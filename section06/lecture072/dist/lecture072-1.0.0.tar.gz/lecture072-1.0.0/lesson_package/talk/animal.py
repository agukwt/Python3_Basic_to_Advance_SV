# from section06.lecture070.lesson_package.tools import utils
# import section06.lecture070.lesson_package.tools.utils
import lesson_package.tools.utils


def sing():
    return 'sing$BBGVVJBNNL'

def cry():
    return 'cry#nBIUGIGBB'