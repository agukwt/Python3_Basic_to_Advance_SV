# -*- coding: utf-8 -*-

def say_twice(word):
    return (word + '!') * 2
